import engine
from engine import mine_engine
name = "pyMine"
